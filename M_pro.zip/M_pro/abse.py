import os
import io
import cv2
import numpy as np
from PIL import Image
from rembg import remove
from typing import Optional
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.responses import Response, FileResponse

app = FastAPI(title="Photo Editor API - محرر الصور الشامل")

# ==========================================
# دمج واستيراد الصور من المسارات والتنسيقات
# ==========================================

def load_image_from_source(file: Optional[UploadFile] = None, file_path: Optional[str] = None) -> Image.Image:
    """قراءة الصورة سواء كانت مرفوعة كـ File أو مسار محلي File Path من الجهاز"""
    if file_path:
        if not os.path.exists(file_path):
            raise HTTPException(status_code=404, detail="المسار المرفق غير موجود على الجهاز")
        try:
            return Image.open(file_path).convert("RGBA")
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"فشل قراءة الصورة من المسار: {str(e)}")
    elif file:
        contents = file.file.read()
        return Image.open(io.BytesIO(contents)).convert("RGBA")
    else:
        raise HTTPException(status_code=400, detail="يرجى إرسال ملف صورة أو تحديد مسار الصورة (file_path)")

def pil_to_cv2(pil_image: Image.Image) -> np.ndarray:
    """تحويل صورة PIL إلى OpenCV (BGR/BGRA)"""
    numpy_image = np.array(pil_image)
    if numpy_image.shape[2] == 4:
        return cv2.cvtColor(numpy_image, cv2.COLOR_RGBA2BGRA)
    return cv2.cvtColor(numpy_image, cv2.COLOR_RGB2BGR)

def cv2_to_pil(cv2_image: np.ndarray) -> Image.Image:
    """تحويل صورة OpenCV إلى PIL (RGBA)"""
    if len(cv2_image.shape) == 2: # Gray
        return Image.fromarray(cv2_image).convert("RGBA")
    if cv2_image.shape[2] == 4: # BGRA
        return Image.fromarray(cv2.cvtColor(cv2_image, cv2.COLOR_BGRA2RGBA))
    return Image.fromarray(cv2.cvtColor(cv2_image, cv2.COLOR_BGR2RGB)).convert("RGBA")

def image_to_response(img: Image.Image, output_format: str = "PNG") -> Response:
    """تصدير الصورة بالنظام المطلوب وإرجاعها"""
    fmt = output_format.upper()
    if fmt == "JPG":
        fmt = "JPEG"
    
    output_io = io.BytesIO()
    if fmt == "JPEG":
        # تحويل RGBA إلى RGB للأنواع التي لا تدعم الشفافية
        bg = Image.new("RGB", img.size, (255, 255, 255))
        bg.paste(img, mask=img.split()[3] if len(img.split()) == 4 else None)
        bg.save(output_io, format=fmt, quality=95)
        media_type = "image/jpeg"
    else:
        img.save(output_io, format=fmt)
        media_type = f"image/{fmt.lower()}"
        
    return Response(content=output_io.getvalue(), media_type=media_type)

# ==========================================
# 1. التحويل بين صيغ الصور (Format Conversion)
# ==========================================

@app.post("/api/convert-format")
async def convert_format(
    file: Optional[UploadFile] = File(None),
    file_path: Optional[str] = Form(None),
    target_format: str = Form("PNG") # PNG, JPEG, WEBP, BMP, TIFF
):
    img = load_image_from_source(file, file_path)
    return image_to_response(img, target_format)

# ==========================================
# 2. إزالة الخلفية (Background Removal)
# ==========================================

@app.post("/api/remove-background")
async def remove_background(
    file: Optional[UploadFile] = File(None),
    file_path: Optional[str] = Form(None)
):
    img = load_image_from_source(file, file_path)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    output_bytes = remove(buf.getvalue())
    no_bg_img = Image.open(io.BytesIO(output_bytes)).convert("RGBA")
    return image_to_response(no_bg_img, "PNG")

# ==========================================
# 3. القص، التكبير/التصغير، الدوران والقلب
# ==========================================

@app.post("/api/transform")
async def transform_image(
    file: Optional[UploadFile] = File(None),
    file_path: Optional[str] = Form(None),
    crop_x: Optional[int] = Form(None),
    crop_y: Optional[int] = Form(None),
    crop_w: Optional[int] = Form(None),
    crop_h: Optional[int] = Form(None),
    resize_w: Optional[int] = Form(None),
    resize_h: Optional[int] = Form(None),
    rotate_angle: int = Form(0), # 90, 180, 270 إلخ
    flip_horizontal: bool = Form(False),
    flip_vertical: bool = Form(False)
):
    pil_img = load_image_from_source(file, file_path)
    cv_img = pil_to_cv2(pil_img)

    # القص (Crop)
    if crop_x is not None and crop_y is not None and crop_w and crop_h:
        h_img, w_img = cv_img.shape[:2]
        x1, y1 = max(0, crop_x), max(0, crop_y)
        x2, y2 = min(w_img, x1 + crop_w), min(h_img, y1 + crop_h)
        cv_img = cv_img[y1:y2, x1:x2]

    # إعادة الحجم (Resize)
    if resize_w and resize_h and resize_w > 0 and resize_h > 0:
        cv_img = cv2.resize(cv_img, (resize_w, resize_h), interpolation=cv2.INTER_AREA)

    # القلب (Flip)
    if flip_horizontal and flip_vertical:
        cv_img = cv2.flip(cv_img, -1)
    elif flip_horizontal:
        cv_img = cv2.flip(cv_img, 1)
    elif flip_vertical:
        cv_img = cv2.flip(cv_img, 0)

    # الدوران (Rotate)
    if rotate_angle != 0:
        if rotate_angle == 90:
            cv_img = cv2.rotate(cv_img, cv2.ROTATE_90_CLOCKWISE)
        elif rotate_angle == 180:
            cv_img = cv2.rotate(cv_img, cv2.ROTATE_180)
        elif rotate_angle == 270:
            cv_img = cv2.rotate(cv_img, cv2.ROTATE_90_COUNTERCLOCKWISE)
        else:
            (h, w) = cv_img.shape[:2]
            center = (w // 2, h // 2)
            M = cv2.getRotationMatrix2D(center, rotate_angle, 1.0)
            cv_img = cv2.warpAffine(cv_img, M, (w, h))

    return image_to_response(cv2_to_pil(cv_img), "PNG")

# ==========================================
# 4. تحسينات البكسل (Pixel-Level Enhancements)
# ==========================================

@app.post("/api/enhance-pixel")
async def enhance_pixel(
    file: Optional[UploadFile] = File(None),
    file_path: Optional[str] = Form(None),
    brightness: float = Form(0),   # نطاق من -100 إلى 100
    contrast: float = Form(1.0),   # نطاق من 0.1 إلى 3.0
    gamma: float = Form(1.0)       # تصحيح جاما
):
    pil_img = load_image_from_source(file, file_path)
    cv_img = pil_to_cv2(pil_img)
    
    has_alpha = cv_img.shape[2] == 4
    if has_alpha:
        b, g, r, a = cv2.split(cv_img)
        rgb_img = cv2.merge([b, g, r])
    else:
        rgb_img = cv_img

    # السطوع والتباين
    rgb_img = cv2.convertScaleAbs(rgb_img, alpha=contrast, beta=brightness)

    # تصحيح الجاما
    if gamma != 1.0 and gamma > 0:
        invGamma = 1.0 / gamma
        table = np.array([((i / 255.0) ** invGamma) * 255 for i in np.arange(256)]).astype("uint8")
        rgb_img = cv2.LUT(rgb_img, table)

    if has_alpha:
        cv_img = cv2.merge([rgb_img[:, :, 0], rgb_img[:, :, 1], rgb_img[:, :, 2], a])
    else:
        cv_img = rgb_img

    return image_to_response(cv2_to_pil(cv_img), "PNG")

# ==========================================
# 5. فلاتر التنعيم والتحديد (Filters)
# ==========================================

@app.post("/api/apply-filter")
async def apply_filter(
    file: Optional[UploadFile] = File(None),
    file_path: Optional[str] = Form(None),
    filter_type: str = Form("gaussian"), # gaussian, median, sharpen, sobel, canny
    kernel_size: int = Form(5)
):
    pil_img = load_image_from_source(file, file_path)
    cv_img = pil_to_cv2(pil_img)

    k = kernel_size if kernel_size % 2 == 1 else kernel_size + 1

    if filter_type == "gaussian":
        cv_img = cv2.GaussianBlur(cv_img, (k, k), 0)
    elif filter_type == "median":
        cv_img = cv2.medianBlur(cv_img, k)
    elif filter_type == "sharpen":
        kernel = np.array([[0, -1, 0], [-1, 5, -1], [0, -1, 0]])
        cv_img = cv2.filter2D(cv_img, -1, kernel)
    elif filter_type == "sobel":
        gray = cv2.cvtColor(cv_img, cv2.COLOR_BGR2GRAY)
        gx = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
        gy = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
        cv_img = cv2.convertScaleAbs(cv2.magnitude(gx, gy))
        cv_img = cv2.cvtColor(cv_img, cv2.COLOR_GRAY2BGR)
    elif filter_type == "canny":
        gray = cv2.cvtColor(cv_img, cv2.COLOR_BGR2GRAY)
        edges = cv2.Canny(gray, 100, 200)
        cv_img = cv2.cvtColor(edges, cv2.COLOR_GRAY2BGR)

    return image_to_response(cv2_to_pil(cv_img), "PNG")

# ==========================================
# 6. دمج صورتين / اختيار خلفية منتجات
# ==========================================

# إنشاء مجلد خلفيات المنتجات افتراضياً
BG_LIBRARY_DIR = "./product_backgrounds"
os.makedirs(BG_LIBRARY_DIR, exist_ok=True)

@app.post("/api/blend-images")
async def blend_images(
    fg_file: Optional[UploadFile] = File(None),
    fg_path: Optional[str] = Form(None),
    bg_file: Optional[UploadFile] = File(None),
    bg_path: Optional[str] = Form(None),
    preset_bg_name: Optional[str] = Form(None), # اختيار من المكتبة
    alpha: float = Form(1.0),                  # مدى الشفافية (0.0 إلى 1.0)
    auto_remove_fg_bg: bool = Form(True)        # إزالة خلفية المنتج تلقائياً قبل الدمج
):
    # 1. جلب صورة المقدمة (المنتج)
    fg_img = load_image_from_source(fg_file, fg_path)

    # إزالة خلفيتها إذا تم تفعيل الخيار
    if auto_remove_fg_bg:
        buf = io.BytesIO()
        fg_img.save(buf, format="PNG")
        fg_no_bg_bytes = remove(buf.getvalue())
        fg_img = Image.open(io.BytesIO(fg_no_bg_bytes)).convert("RGBA")

    # 2. جلب صورة الخلفية
    if preset_bg_name:
        selected_bg_path = os.path.join(BG_LIBRARY_DIR, preset_bg_name)
        if not os.path.exists(selected_bg_path):
            raise HTTPException(status_code=404, detail="اسم الخلفية غير موجود بمكتبة استوديو المنتجات")
        bg_img = Image.open(selected_bg_path).convert("RGBA")
    else:
        bg_img = load_image_from_source(bg_file, bg_path)

    # توحيد حجم الخلفية مع المنتج
    bg_img = bg_img.resize(fg_img.size)

    # ضبط الشفافية (Opacity/Alpha)
    if alpha < 1.0:
        r, g, b, a = fg_img.split()
        a = a.point(lambda p: int(p * alpha))
        fg_img = Image.merge("RGBA", (r, g, b, a))

    # دمج الصورة الفوقية مع الخلفية
    final_img = Image.alpha_composite(bg_img, fg_img)
    return image_to_response(final_img, "PNG")

# استعراض أسماء الخلفيات المتاحة بمكتبة استوديو المنتجات
@app.get("/api/product-backgrounds")
async def list_product_backgrounds():
    files = [f for f in os.listdir(BG_LIBRARY_DIR) if f.lower().endswith(('.png', '.jpg', '.jpeg', '.webp'))]
    return {"backgrounds": files}
