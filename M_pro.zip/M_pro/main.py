import sys
import os
import cv2
import numpy as np
from PyQt5 import QtCore, QtGui, QtWidgets

# ==============================================================================
# 1. دوال معالجة الصور والرؤية الحاسوبية (Core Engine - Safe Processing)
# ==============================================================================

def ensure_bgr(frame):
    """حماية القنوات لمنع الأخطاء عند تراكم العمليات"""
    if frame is None:
        return None
    if len(frame.shape) == 2:
        return cv2.cvtColor(frame, cv2.COLOR_GRAY2BGR)
    elif frame.shape[2] == 4:
        return cv2.cvtColor(frame, cv2.COLOR_BGRA2BGR)
    return frame

def adjust_brightness_contrast(frame, brightness=0, contrast=0):
    alpha = 1.0 + (contrast / 100.0)
    beta = brightness
    return cv2.convertScaleAbs(frame, alpha=alpha, beta=beta)

def gamma_correction(frame, gamma=1.0):
    if gamma <= 0: gamma = 0.1
    invGamma = 1.0 / gamma
    table = np.array([((i / 255.0) ** invGamma) * 255 for i in np.arange(256)]).astype("uint8")
    return cv2.LUT(frame, table)

def histogram_equalization(frame):
    if len(frame.shape) == 2:
        res = cv2.equalizeHist(frame)
        return ensure_bgr(res)
    ycrcb = cv2.cvtColor(frame, cv2.COLOR_BGR2YCrCb)
    ycrcb[:, :, 0] = cv2.equalizeHist(ycrcb[:, :, 0])
    return cv2.cvtColor(ycrcb, cv2.COLOR_YCrCb2BGR)

def clahe_equalization(frame, clipLimit=3.0):
    lab = cv2.cvtColor(frame, cv2.COLOR_BGR2LAB)
    l, a, b = cv2.split(lab)
    clahe = cv2.createCLAHE(clipLimit=clipLimit, tileGridSize=(8, 8))
    cl = clahe.apply(l)
    limg = cv2.merge((cl, a, b))
    return cv2.cvtColor(limg, cv2.COLOR_LAB2BGR)

def denoise_gaussian(frame): return cv2.GaussianBlur(frame, (5, 5), 0)
def denoise_median(frame): return cv2.medianBlur(frame, 5)
def denoise_bilateral(frame): return cv2.bilateralFilter(frame, 9, 75, 75)
def denoise_nlmeans(frame): return cv2.fastNlMeansDenoisingColored(frame, None, 10, 10, 7, 21)

def sharpen(frame):
    kernel = np.array([[0, -1, 0], [-1, 5, -1], [0, -1, 0]])
    return cv2.filter2D(frame, -1, kernel)

def smoothing(frame, ksize=5): return cv2.blur(frame, (ksize, ksize))

def edge_sobel(frame):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    grad_x = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
    grad_y = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
    grad = cv2.convertScaleAbs(cv2.magnitude(grad_x, grad_y))
    return ensure_bgr(grad)

def edge_canny(frame):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray, 100, 200)
    return ensure_bgr(edges)

def edge_laplacian(frame):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    lap = cv2.Laplacian(gray, cv2.CV_64F)
    lap = cv2.convertScaleAbs(lap)
    return ensure_bgr(lap)

def line_detection(frame):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray, 50, 150, apertureSize=3)
    lines = cv2.HoughLinesP(edges, 1, np.pi/180, threshold=100, minLineLength=50, maxLineGap=10)
    line_img = frame.copy()
    if lines is not None:
        for line in lines:
            x1, y1, x2, y2 = line[0]
            cv2.line(line_img, (x1, y1), (x2, y2), (0, 0, 255), 2)
    return line_img

def threshold_binary(frame):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    _, th = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY)
    return ensure_bgr(th)

def threshold_adaptive_mean(frame):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    th = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY, 11, 2)
    return ensure_bgr(th)

def threshold_adaptive_gaussian(frame):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    th = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2)
    return ensure_bgr(th)

def morph_erode(frame): return cv2.erode(frame, np.ones((5,5),np.uint8), iterations=1)
def morph_dilate(frame): return cv2.dilate(frame, np.ones((5,5),np.uint8), iterations=1)
def morph_open(frame): return cv2.morphologyEx(frame, cv2.MORPH_OPEN, np.ones((5,5),np.uint8))
def morph_close(frame): return cv2.morphologyEx(frame, cv2.MORPH_CLOSE, np.ones((5,5),np.uint8))
def morph_gradient(frame): return cv2.morphologyEx(frame, cv2.MORPH_GRADIENT, np.ones((5,5),np.uint8))
def morph_tophat(frame): return cv2.morphologyEx(frame, cv2.MORPH_TOPHAT, np.ones((5,5),np.uint8))
def morph_blackhat(frame): return cv2.morphologyEx(frame, cv2.MORPH_BLACKHAT, np.ones((5,5),np.uint8))

def color_space_convert(frame, mode):
    if mode == "Grayscale":
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        return ensure_bgr(gray)
    elif mode == "HSV":
        return cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    elif mode == "LAB":
        return cv2.cvtColor(frame, cv2.COLOR_BGR2LAB)
    elif mode == "YCrCb":
        return cv2.cvtColor(frame, cv2.COLOR_BGR2YCrCb)
    elif mode == "Invert":
        return cv2.bitwise_not(frame)
    return frame

def segmentation_kmeans(frame, k=3):
    Z = frame.reshape((-1,3))
    Z = np.float32(Z)
    criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 10, 1.0)
    _, label, center = cv2.kmeans(Z, k, None, criteria, 10, cv2.KMEANS_RANDOM_CENTERS)
    center = np.uint8(center)
    res = center[label.flatten()]
    return res.reshape((frame.shape))

def watershed_segmentation(frame):
    img = frame.copy()
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    _, thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    kernel = np.ones((3,3), np.uint8)
    opening = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel, iterations=2)
    sure_bg = cv2.dilate(opening, kernel, iterations=3)
    dist_transform = cv2.distanceTransform(opening, cv2.DIST_L2, 5)
    _, sure_fg = cv2.threshold(dist_transform, 0.5 * dist_transform.max(), 255, 0)
    sure_fg = np.uint8(sure_fg)
    unknown = cv2.subtract(sure_bg, sure_fg)
    _, markers = cv2.connectedComponents(sure_fg)
    markers = markers + 1
    markers[unknown == 255] = 0
    markers = cv2.watershed(img, markers)
    img[markers == -1] = [0, 0, 255]
    return img

# ==============================================================================
# 2. أنماط الواجهة والتحكم المتقدم
# ==============================================================================

BLACK_PRO_STYLE = """
QMainWindow { background-color: #050505; }
QWidget { color: #f4f4f5; font-family: 'Segoe UI', Arial, sans-serif; font-size: 13px; }
QGroupBox { border: 1px solid #27272a; border-radius: 8px; margin-top: 12px; padding-top: 10px; background-color: #09090b; font-weight: bold; color: #38bdf8; }
QGroupBox::title { subcontrol-origin: margin; left: 12px; padding: 0 5px; }
QPushButton { background-color: #18181b; color: #f4f4f5; border: 1px solid #27272a; border-radius: 6px; padding: 8px 14px; font-weight: 600; }
QPushButton:hover { background-color: #2563eb; border-color: #3b82f6; }
QPushButton:pressed { background-color: #1d4ed8; }
QLineEdit, QComboBox, QSpinBox { background-color: #000000; border: 1px solid #27272a; border-radius: 6px; padding: 6px; color: #00f0ff; selection-background-color: #2563eb; }
QComboBox QAbstractItemView { background-color: #000000; color: #00f0ff; selection-background-color: #1e293b; border: 1px solid #27272a; }
QTabBar::tab { background: #09090b; color: #a1a1aa; padding: 8px 16px; border-top-left-radius: 6px; border-top-right-radius: 6px; margin-right: 2px; font-weight: bold; }
QTabBar::tab:selected { background: #2563eb; color: #ffffff; }
QSlider::groove:horizontal { height: 6px; background: #27272a; border-radius: 3px; }
QSlider::handle:horizontal { background: #00f0ff; width: 16px; margin: -5px 0; border-radius: 8px; }
QStatusBar { background-color: #09090b; color: #a1a1aa; border-top: 1px solid #27272a; }
"""

class SmartEnhancerPro(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("VisionStudio Pro - محرر معالجة الصور والفيديو المتقدم")
        self.setGeometry(30, 30, 1400, 880)
        self.setStyleSheet(BLACK_PRO_STYLE)

        self.zoom_scale = 1.0
        self.orig_image = None
        self.working_image = None  # الصورة التي يجري تعديلها وتطبيق العمليات التراكمية عليها
        self.proc_frame = None
        self.cap = None
        self.timer = QtCore.QTimer(self)
        self.fps = 30
        self.playing = False
        
        self.crop_rect = None
        self.resize_scale = 1.0
        self.rotate_angle = 0
        self.camera_index = 0

        self.init_ui()

    def init_ui(self):
        central = QtWidgets.QWidget()
        self.setCentralWidget(central)
        main_layout = QtWidgets.QHBoxLayout(central)
        main_layout.setSpacing(12)

        # الشريط الجانبي
        sidebar = QtWidgets.QVBoxLayout()
        sidebar_widget = QtWidgets.QWidget()
        sidebar_widget.setLayout(sidebar)
        sidebar_widget.setFixedWidth(430)

        # 1. وسائط المصدر
        gb_io = QtWidgets.QGroupBox("المصدر والوسائط (Media Source)")
        io_layout = QtWidgets.QVBoxLayout()

        grid_io = QtWidgets.QGridLayout()
        self.btn_load_image = QtWidgets.QPushButton("🖼️ فتح صورة")
        self.btn_open_cam = QtWidgets.QPushButton("📹 الكاميرا")
        self.btn_snap_cam = QtWidgets.QPushButton("📸 التقاط من الكاميرا")
        self.btn_save_img = QtWidgets.QPushButton("💾 حفظ الصورة")

        grid_io.addWidget(self.btn_load_image, 0, 0)
        grid_io.addWidget(self.btn_open_cam, 0, 1)
        grid_io.addWidget(self.btn_snap_cam, 1, 0)
        grid_io.addWidget(self.btn_save_img, 1, 1)
        io_layout.addLayout(grid_io)

        path_layout = QtWidgets.QHBoxLayout()
        self.txt_path_input = QtWidgets.QLineEdit()
        self.txt_path_input.setPlaceholderText("أدخل مسار صورة محلي...")
        self.btn_load_path = QtWidgets.QPushButton("تحميل المسار")
        path_layout.addWidget(self.txt_path_input)
        path_layout.addWidget(self.btn_load_path)
        io_layout.addLayout(path_layout)

        gb_io.setLayout(io_layout)
        sidebar.addWidget(gb_io)

        # 2. تبويب العمليات الفنية والتحسين
        self.tabs = QtWidgets.QTabWidget()

        # Tab Operations
        self.tab_ops = QtWidgets.QWidget()
        ops_layout = QtWidgets.QVBoxLayout(self.tab_ops)
        self.combo_ops = QtWidgets.QComboBox()
        self.combo_ops.addItems([
            "اختر العملية (None)", "property of photo", "Histogram Equalization",
            "Gaussian Denoise", "Median Denoise", "Bilateral Denoise", "Non-local Means Denoise",
            "Sharpen", "Smoothing", "Edge Sobel", "Edge Canny", "Edge Laplacian", "Line Detection",
            "Threshold Binary", "Threshold Adaptive Mean", "Threshold Adaptive Gaussian",
            "Morph Erode", "Morph Dilate", "Morph Open", "Morph Close", "Morph Gradient", "Morph TopHat", "Morph BlackHat",
            "Color Space: Grayscale", "Color Space: HSV", "Color Space: LAB", "Color Space: YCrCb", "Color Space: Invert",
            "Segmentation KMeans", "Watershed Segmentation"
        ])
        ops_layout.addWidget(self.combo_ops)
        
        self.btn_reset_img = QtWidgets.QPushButton("🔄 إعادة ضبط للصورة الأصلية")
        self.btn_reset_img.setStyleSheet("background-color: #3f3f46; color: #ffffff;")
        ops_layout.addWidget(self.btn_reset_img)
        self.tabs.addTab(self.tab_ops, "العمليات الفنية التراكمية")

        # Tab Enhancements
        self.tab_enh = QtWidgets.QWidget()
        enh_layout = QtWidgets.QFormLayout(self.tab_enh)
        self.combo_enh = QtWidgets.QComboBox()
        self.combo_enh.addItems(["اختر تحسين", "Brightness/Contrast", "Gamma Correction", "CLAHE Equalization"])
        enh_layout.addRow("النوع:", self.combo_enh)

        self.slider_brightness = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.slider_brightness.setRange(-100, 100)
        self.slider_brightness.setValue(0)
        enh_layout.addRow("Brightness", self.slider_brightness)

        self.slider_contrast = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.slider_contrast.setRange(-100, 100)
        self.slider_contrast.setValue(0)
        enh_layout.addRow("Contrast", self.slider_contrast)

        self.slider_gamma = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.slider_gamma.setRange(10, 300)
        self.slider_gamma.setValue(100)
        enh_layout.addRow("Gamma (×0.01)", self.slider_gamma)
        self.tabs.addTab(self.tab_enh, "تحسين الألوان")

        sidebar.addWidget(self.tabs)

        # 3. التحويلات
        gb_trans = QtWidgets.QGroupBox("التحويلات الهندسيّة")
        trans_layout = QtWidgets.QVBoxLayout()

        btn_crop = QtWidgets.QPushButton("✂️ قص (Crop Custom)")
        btn_crop.clicked.connect(self.crop_dialog)
        trans_layout.addWidget(btn_crop)

        resize_box = QtWidgets.QHBoxLayout()
        resize_box.addWidget(QtWidgets.QLabel("الحجم %:"))
        self.spin_scale = QtWidgets.QSpinBox()
        self.spin_scale.setRange(10, 400)
        self.spin_scale.setValue(100)
        btn_apply_resize = QtWidgets.QPushButton("تطبيق الحجم")
        btn_apply_resize.clicked.connect(self.apply_resize_setting)
        resize_box.addWidget(self.spin_scale)
        resize_box.addWidget(btn_apply_resize)
        trans_layout.addLayout(resize_box)

        rotate_box = QtWidgets.QHBoxLayout()
        btn_rot_left = QtWidgets.QPushButton("↺ 90°")
        btn_rot_right = QtWidgets.QPushButton("↻ 90°")
        btn_rot_left.clicked.connect(lambda: self.rotate_by(-90))
        btn_rot_right.clicked.connect(lambda: self.rotate_by(90))
        rotate_box.addWidget(btn_rot_left)
        rotate_box.addWidget(btn_rot_right)
        trans_layout.addLayout(rotate_box)

        gb_trans.setLayout(trans_layout)
        sidebar.addWidget(gb_trans)

        sidebar.addStretch()

        # المساحة الرئيسية
        workspace = QtWidgets.QVBoxLayout()

        zoom_bar = QtWidgets.QHBoxLayout()
        lbl_title = QtWidgets.QLabel("معاينة العرض الحي (Interactive Dual Viewer)")
        lbl_title.setStyleSheet("font-size: 16px; font-weight: bold; color: #00f0ff;")
        self.btn_zoom_in = QtWidgets.QPushButton("🔍 تكبير")
        self.btn_zoom_out = QtWidgets.QPushButton("🔎 تصغير")
        zoom_bar.addWidget(lbl_title)
        zoom_bar.addStretch()
        zoom_bar.addWidget(self.btn_zoom_in)
        zoom_bar.addWidget(self.btn_zoom_out)
        workspace.addLayout(zoom_bar)

        display_layout = QtWidgets.QHBoxLayout()

        # Before Panel
        frame_before_box = QtWidgets.QVBoxLayout()
        lbl_b_title = QtWidgets.QLabel("الصورة الأصلية / بث الكاميرا (BEFORE)")
        lbl_b_title.setAlignment(QtCore.Qt.AlignCenter)
        lbl_b_title.setStyleSheet("color: #a1a1aa; font-weight: bold;")
        self.label_before = QtWidgets.QLabel("قم بفتح صورة أو تشغيل الكاميرا")
        self.label_before.setAlignment(QtCore.Qt.AlignCenter)
        self.label_before.setMinimumSize(420, 480)
        self.label_before.setStyleSheet("background-color: #000000; border: 2px dashed #27272a; border-radius: 10px;")
        frame_before_box.addWidget(lbl_b_title)
        frame_before_box.addWidget(self.label_before)

        # After Panel
        frame_after_box = QtWidgets.QVBoxLayout()
        lbl_a_title = QtWidgets.QLabel("الصورة المعالجة الحالية (AFTER)")
        lbl_a_title.setAlignment(QtCore.Qt.AlignCenter)
        lbl_a_title.setStyleSheet("color: #00f0ff; font-weight: bold;")
        self.label_after = QtWidgets.QLabel("النتائج وتراكم العمليات يظهر هنا")
        self.label_after.setAlignment(QtCore.Qt.AlignCenter)
        self.label_after.setMinimumSize(420, 480)
        self.label_after.setStyleSheet("background-color: #000000; border: 2px solid #2563eb; border-radius: 10px;")
        frame_after_box.addWidget(lbl_a_title)
        frame_after_box.addWidget(self.label_after)

        display_layout.addLayout(frame_before_box)
        display_layout.addLayout(frame_after_box)
        workspace.addLayout(display_layout)

        main_layout.addWidget(sidebar_widget)
        main_layout.addLayout(workspace)

        # الربط والأحداث
        self.btn_load_image.clicked.connect(self.load_image)
        self.btn_open_cam.clicked.connect(self.open_camera)
        self.btn_snap_cam.clicked.connect(self.snap_from_camera)
        self.btn_load_path.clicked.connect(self.load_from_custom_path)
        self.btn_save_img.clicked.connect(self.save_image)
        self.btn_reset_img.clicked.connect(self.reset_working_image)

        self.btn_zoom_in.clicked.connect(self.zoom_in)
        self.btn_zoom_out.clicked.connect(self.zoom_out)

        self.timer.timeout.connect(self.next_camera_frame)

        # ربط تغير العمليات بالتحديث الفوري والتراكمي داخل الصورة
        self.combo_ops.currentIndexChanged.connect(self.apply_operation_to_working_image)
        self.combo_enh.currentIndexChanged.connect(self.apply_operation_to_working_image)
        self.slider_brightness.valueChanged.connect(self.apply_operation_to_working_image)
        self.slider_contrast.valueChanged.connect(self.apply_operation_to_working_image)
        self.slider_gamma.valueChanged.connect(self.apply_operation_to_working_image)

        self.statusBar().showMessage("النظام جاهز للعمل - Ready")

    # -------------------------------------------------------------
    # إدارة المصادر المباشرة والتحويلات
    # -------------------------------------------------------------
    def stop_camera_if_active(self):
        """إيقاف الكاميرا بأمان وحل مشكلة رسالة الخطأ عند تحميل الصورة"""
        if self.timer.isActive():
            self.timer.stop()
        if self.cap is not None:
            try:
                self.cap.release()
            except Exception as e:
                print("Camera Release Error:", e)
            self.cap = None

    def open_camera(self):
        self.stop_camera_if_active()
        cap = cv2.VideoCapture(self.camera_index)
        if not cap.isOpened():
            QtWidgets.QMessageBox.warning(self, "خطأ بالكميرا", "تعذر فتح الكاميرا الموصلة بالجهاز.")
            return
        self.cap = cap
        self.timer.setInterval(33)
        self.timer.start()
        self.statusBar().showMessage("تم فتح بث الكاميرا الحية")

    def next_camera_frame(self):
        if self.cap is None: return
        ret, frame = self.cap.read()
        if ret:
            pix = self.cv2qt(frame)
            self.label_before.setPixmap(pix)

    def snap_from_camera(self):
        """التقاط فريم من الكاميرا وتعيينه كصورة للعمليات"""
        if self.cap is not None:
            ret, frame = self.cap.read()
            if ret and frame is not None:
                self.stop_camera_if_active()
                self.orig_image = frame.copy()
                self.working_image = frame.copy()
                self.proc_frame = frame.copy()
                self.update_displays()
                self.statusBar().showMessage("تم التقاط الصورة من الكاميرا بنجاح وجاهزة للتعديل")
            else:
                QtWidgets.QMessageBox.warning(self, "خطأ", "فشل التقاط الفريم من الكاميرا.")
        else:
            QtWidgets.QMessageBox.information(self, "تنبيه", "قم بفتح الكاميرا أولاً للتقاط الصورة.")

    def load_from_custom_path(self):
        path = self.txt_path_input.text().strip()
        if (path.startswith('"') and path.endswith('"')) or (path.startswith("'") and path.endswith("'")):
            path = path[1:-1]

        if not path or not os.path.exists(path):
            QtWidgets.QMessageBox.warning(self, "خطأ بالمسار", "المسار المكتوب غير موجود تحقق من صحة المسار مجدداً.")
            return

        self.stop_camera_if_active() # إيقاف الكاميرا أولاً لتفادي التعارض
        img = cv2.imread(path)
        if img is not None:
            self.orig_image = img.copy()
            self.working_image = img.copy()
            self.proc_frame = img.copy()
            self.update_displays()
            self.statusBar().showMessage(f"تم تحميل الصورة بنجاح: {os.path.basename(path)}")
        else:
            QtWidgets.QMessageBox.warning(self, "خطأ بالملف", "فشل قراءة ملف الصورة المحدد.")

    def load_image(self):
        self.stop_camera_if_active()
        path, _ = QtWidgets.QFileDialog.getOpenFileName(self, "اختر صورة", "", "Images (*.png *.jpg *.jpeg *.bmp *.webp)")
        if path:
            self.txt_path_input.setText(path)
            self.load_from_custom_path()

    # -------------------------------------------------------------
    # منطق تنفيذ المعالجة وتراكم العمليات داخل الصورة
    # -------------------------------------------------------------
    def apply_operation_to_working_image(self):
        """تطبيق العملية الحالية وتحديث الصورة المعالجة التراكمية"""
        if self.working_image is None:
            return

        out = self.working_image.copy()
        op = self.combo_ops.currentText()

        # تنفيذ العملية الفنية المختارة
        if op == "property of photo": 
            self.show_image_info(out)
        elif op == "Histogram Equalization": 
            out = histogram_equalization(out)
        elif op == "Gaussian Denoise": 
            out = denoise_gaussian(out)
        elif op == "Median Denoise": 
            out = denoise_median(out)
        elif op == "Bilateral Denoise": 
            out = denoise_bilateral(out)
        elif op == "Non-local Means Denoise": 
            out = denoise_nlmeans(out)
        elif op == "Smoothing": 
            out = smoothing(out)
        elif op == "Sharpen": 
            out = sharpen(out)
        elif op == "Edge Sobel": 
            out = edge_sobel(out)
        elif op == "Edge Canny": 
            out = edge_canny(out)
        elif op == "Edge Laplacian": 
            out = edge_laplacian(out)
        elif op == "Line Detection": 
            out = line_detection(out)
        elif op == "Threshold Binary": 
            out = threshold_binary(out)
        elif op == "Threshold Adaptive Mean": 
            out = threshold_adaptive_mean(out)
        elif op == "Threshold Adaptive Gaussian": 
            out = threshold_adaptive_gaussian(out)
        elif op == "Morph Erode": 
            out = morph_erode(out)
        elif op == "Morph Dilate": 
            out = morph_dilate(out)
        elif op == "Morph Open": 
            out = morph_open(out)
        elif op == "Morph Close": 
            out = morph_close(out)
        elif op == "Morph Gradient": 
            out = morph_gradient(out)
        elif op == "Morph TopHat": 
            out = morph_tophat(out)
        elif op == "Morph BlackHat": 
            out = morph_blackhat(out)
        elif op.startswith("Color Space:"):
            mode = op.split(":")[1].strip()
            out = color_space_convert(out, mode)
        elif op == "Segmentation KMeans": 
            out = segmentation_kmeans(out)
        elif op == "Watershed Segmentation": 
            out = watershed_segmentation(out)

        # تحسينات الألوان
        enh = self.combo_enh.currentText()
        if enh == "Brightness/Contrast":
            out = adjust_brightness_contrast(out, self.slider_brightness.value(), self.slider_contrast.value())
        elif enh == "Gamma Correction":
            out = gamma_correction(out, self.slider_gamma.value() / 100.0)
        elif enh == "CLAHE Equalization":
            out = clahe_equalization(out)

        out = ensure_bgr(out)
        
        # ربط وتحديث الصورة العاملة بالنتيجة للعمل عليها بالخطوات القادمة
        if op != "اختر العملية (None)" or enh != "اختر تحسين":
            self.working_image = out.copy()
            
        self.proc_frame = out
        self.update_displays()

    def reset_working_image(self):
        """إعادة ضبط الصورة لتصبح مطابقة للأصلية عند البدء من جديد"""
        if self.orig_image is not None:
            self.working_image = self.orig_image.copy()
            self.proc_frame = self.orig_image.copy()
            self.combo_ops.setCurrentIndex(0)
            self.combo_enh.setCurrentIndex(0)
            self.update_displays()
            self.statusBar().showMessage("تم إعادة ضبط الصورة إلى وضعها الأصلي")

    # -------------------------------------------------------------
    # تحويلات هندسية ومعاينة
    # -------------------------------------------------------------
    def crop_dialog(self):
        if self.working_image is None:
            QtWidgets.QMessageBox.information(self, "تنبيه", "قم بتحميل أو التقاط صورة أولاً.")
            return
        text, ok = QtWidgets.QInputDialog.getText(self, "القص", "أدخل الإحداثيات x,y,w,h (مثال: 50,50,300,300):")
        if ok and text:
            try:
                parts = [int(p.strip()) for p in text.split(',')]
                if len(parts) == 4:
                    x, y, w, h = parts
                    H, W = self.working_image.shape[:2]
                    x, y = max(0, min(x, W-1)), max(0, min(y, H-1))
                    w, h = max(1, min(w, W-x)), max(1, min(h, H-y))
                    self.working_image = self.working_image[y:y+h, x:x+w]
                    self.apply_operation_to_working_image()
            except:
                QtWidgets.QMessageBox.warning(self, "خطأ", "فشل قراءة قيم الإحداثيات المفصولة بفواصل.")

    def apply_resize_setting(self):
        if self.working_image is None: return
        scale = self.spin_scale.value() / 100.0
        nw = int(self.working_image.shape[1] * scale)
        nh = int(self.working_image.shape[0] * scale)
        if nw > 0 and nh > 0:
            self.working_image = cv2.resize(self.working_image, (nw, nh), interpolation=cv2.INTER_AREA)
            self.apply_operation_to_working_image()

    def rotate_by(self, deg):
        if self.working_image is None: return
        (h, w) = self.working_image.shape[:2]
        center = (w // 2, h // 2)
        M = cv2.getRotationMatrix2D(center, -deg, 1.0)
        cos, sin = np.abs(M[0, 0]), np.abs(M[0, 1])
        nW, nH = int((h * sin) + (w * cos)), int((h * cos) + (w * sin))
        M[0, 2] += (nW / 2) - center[0]
        M[1, 2] += (nH / 2) - center[1]
        self.working_image = cv2.warpAffine(self.working_image, M, (nW, nH))
        self.apply_operation_to_working_image()

    def zoom_in(self):
        self.zoom_scale *= 1.2
        self.update_displays()

    def zoom_out(self):
        self.zoom_scale /= 1.2
        self.update_displays()

    def update_displays(self):
        if self.orig_image is not None:
            pix_before = self.cv2qt(self.orig_image)
            self.label_before.setPixmap(pix_before)
        if self.proc_frame is not None:
            pix_after = self.cv2qt(self.proc_frame)
            if self.zoom_scale != 1.0:
                w = int(pix_after.width() * self.zoom_scale)
                h = int(pix_after.height() * self.zoom_scale)
                pix_after = pix_after.scaled(w, h, QtCore.Qt.KeepAspectRatio)
            self.label_after.setPixmap(pix_after)

    def cv2qt(self, frame):
        if frame is None: return QtGui.QPixmap()
        frame = ensure_bgr(frame)
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        h, w, ch = rgb.shape
        qimg = QtGui.QImage(rgb.data, w, h, ch * w, QtGui.QImage.Format_RGB888)
        pix = QtGui.QPixmap.fromImage(qimg)
        return pix.scaled(self.label_before.width(), self.label_before.height(), QtCore.Qt.KeepAspectRatio)

    def save_image(self):
        if self.proc_frame is None:
            QtWidgets.QMessageBox.information(self, "تنبيه", "لا توجد صورة معالجة جاهزة للحفظ.")
            return
        path, _ = QtWidgets.QFileDialog.getSaveFileName(self, "حفظ الصورة المعالجة", "", "PNG Files (*.png);;JPG Files (*.jpg)")
        if path:
            cv2.imwrite(path, self.proc_frame)
            QtWidgets.QMessageBox.information(self, "تم الحفظ", f"تم حفظ الصورة بنجاح:\n{path}")

    def show_image_info(self, frame):
        if frame is None: return
        h, w = frame.shape[:2]
        ch = frame.shape[2] if len(frame.shape) == 3 else 1
        QtWidgets.QMessageBox.information(self, "خواص الصورة الحالية", f"العرض (Width): {w} px\nالارتفاع (Height): {h} px\nعدد القنوات (Channels): {ch}\nنوع البيانات (Dtype): {frame.dtype}")


# ==============================================================================
# 3. شاشة الترحب السوداء الفاخرة
# ==============================================================================

class ProWelcomeScreen(QtWidgets.QDialog):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("مرحباً بك - VisionStudio Pro")
        self.setFixedSize(550, 420)
        self.setStyleSheet("""
            QDialog { background-color: #050505; border: 1px solid #2563eb; border-radius: 12px; }
            QLabel { color: #f4f4f5; font-family: 'Segoe UI'; }
            QGroupBox { border: 1px solid #27272a; border-radius: 8px; background-color: #09090b; color: #00f0ff; font-weight: bold; }
            QPushButton { background-color: #2563eb; color: white; font-weight: bold; font-size: 15px; border-radius: 8px; padding: 10px; }
            QPushButton:hover { background-color: #1d4ed8; }
        """)

        layout = QtWidgets.QVBoxLayout()
        layout.setContentsMargins(35, 35, 35, 35)

        title = QtWidgets.QLabel("VISION STUDIO PRO")
        title.setAlignment(QtCore.Qt.AlignCenter)
        title.setStyleSheet("font-size: 26px; font-weight: 900; color: #00f0ff; letter-spacing: 2px;")
        layout.addWidget(title)

        subtitle = QtWidgets.QLabel("منصة معالجة الصور والرؤية الحاسوبية الشاملة")
        subtitle.setAlignment(QtCore.Qt.AlignCenter)
        subtitle.setStyleSheet("font-size: 13px; color: #a1a1aa; margin-bottom: 20px;")
        layout.addWidget(subtitle)

        team_box = QtWidgets.QGroupBox("فريق العمل والمشروع")
        team_layout = QtWidgets.QVBoxLayout()
        team_info = QtWidgets.QLabel("• محمد العلواني\n• عبدالله فارع\n• ابان الشرعبي")
        team_info.setStyleSheet("font-size: 14px; color: #d4d4d8; line-height: 150%;")
        team_layout.addWidget(team_info)

        supervisor = QtWidgets.QLabel("تحت إشراف الأستاذ: مالك المصنف")
        supervisor.setStyleSheet("font-size: 13px; font-weight: bold; color: #00f0ff; margin-top: 5px;")
        team_layout.addWidget(supervisor)

        team_box.setLayout(team_layout)
        layout.addWidget(team_box)

        layout.addStretch()

        btn_start = QtWidgets.QPushButton("🚀 بدء تشغيل المحرر الاحترافي")
        btn_start.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        btn_start.clicked.connect(self.accept)
        layout.addWidget(btn_start)

        self.setLayout(layout)


# ==============================================================================
# 4. نقطة الانطلاق الرئيسية (Main)
# ==============================================================================

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    welcome = ProWelcomeScreen()
    if welcome.exec_() == QtWidgets.QDialog.Accepted:
        main_win = SmartEnhancerPro()
        main_win.show()
        sys.exit(app.exec_())
