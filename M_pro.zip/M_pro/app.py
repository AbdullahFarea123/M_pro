import sys
import os
import cv2
import numpy as np
from PyQt5 import QtCore, QtGui, QtWidgets

# ==============================================================================
# 1. دوال معالجة الصور والرؤية الحاسوبية (Core Processing Engine)
# ==============================================================================

def adjust_brightness_contrast(frame, brightness=0, contrast=0):
    alpha = 1.0 + (contrast / 100.0)
    beta = brightness
    return cv2.convertScaleAbs(frame, alpha=alpha, beta=beta)

def gamma_correction(frame, gamma=1.0):
    if gamma <= 0: gamma = 0.1
    invGamma = 1.0 / gamma
    table = np.array([((i / 255.0) ** invGamma) * 255 for i in np.arange(256)]).astype("uint8")
    return cv2.LUT(frame, table)

def histogram_equalization(frame):
    if len(frame.shape) == 2:
        return cv2.equalizeHist(frame)
    ycrcb = cv2.cvtColor(frame, cv2.COLOR_BGR2YCrCb)
    ycrcb[:, :, 0] = cv2.equalizeHist(ycrcb[:, :, 0])
    return cv2.cvtColor(ycrcb, cv2.COLOR_YCrCb2BGR)

def clahe_equalization(frame, clipLimit=3.0):
    lab = cv2.cvtColor(frame, cv2.COLOR_BGR2LAB)
    l, a, b = cv2.split(lab)
    clahe = cv2.createCLAHE(clipLimit=clipLimit, tileGridSize=(8, 8))
    cl = clahe.apply(l)
    limg = cv2.merge((cl, a, b))
    return cv2.cvtColor(limg, cv2.COLOR_LAB2BGR)

def denoise_gaussian(frame): return cv2.GaussianBlur(frame, (5, 5), 0)
def denoise_median(frame): return cv2.medianBlur(frame, 5)
def denoise_bilateral(frame): return cv2.bilateralFilter(frame, 9, 75, 75)
def denoise_nlmeans(frame): return cv2.fastNlMeansDenoisingColored(frame, None, 10, 10, 7, 21)

def sharpen(frame):
    kernel = np.array([[0, -1, 0], [-1, 5, -1], [0, -1, 0]])
    return cv2.filter2D(frame, -1, kernel)

def edge_sobel(frame):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    grad_x = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
    grad_y = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
    grad = cv2.convertScaleAbs(cv2.magnitude(grad_x, grad_y))
    return cv2.cvtColor(grad, cv2.COLOR_GRAY2BGR)

def edge_canny(frame):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray, 100, 200)
    return cv2.cvtColor(edges, cv2.COLOR_GRAY2BGR)

def line_detection(frame):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray, 50, 150, apertureSize=3)
    lines = cv2.HoughLinesP(edges, 1, np.pi/180, threshold=100, minLineLength=50, maxLineGap=10)
    line_img = frame.copy()
    if lines is not None:
        for line in lines:
            x1, y1, x2, y2 = line[0]
            cv2.line(line_img, (x1, y1), (x2, y2), (0, 0, 255), 2)
    return line_img

def threshold_binary(frame):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    _, th = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY)
    return cv2.cvtColor(th, cv2.COLOR_GRAY2BGR)

def morph_erode(frame): return cv2.erode(frame, np.ones((5,5),np.uint8), iterations=1)
def morph_dilate(frame): return cv2.dilate(frame, np.ones((5,5),np.uint8), iterations=1)
def morph_open(frame): return cv2.morphologyEx(frame, cv2.MORPH_OPEN, np.ones((5,5),np.uint8))
def morph_close(frame): return cv2.morphologyEx(frame, cv2.MORPH_CLOSE, np.ones((5,5),np.uint8))

def segmentation_kmeans(frame, k=3):
    Z = frame.reshape((-1,3))
    Z = np.float32(Z)
    criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 10, 1.0)
    _, label, center = cv2.kmeans(Z, k, None, criteria, 10, cv2.KMEANS_RANDOM_CENTERS)
    center = np.uint8(center)
    res = center[label.flatten()]
    return res.reshape((frame.shape))

def smoothing(frame, ksize=5): return cv2.blur(frame, (ksize, ksize))

def watershed_segmentation(frame):
    img = frame.copy()
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    _, thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    kernel = np.ones((3,3), np.uint8)
    opening = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel, iterations=2)
    sure_bg = cv2.dilate(opening, kernel, iterations=3)
    dist_transform = cv2.distanceTransform(opening, cv2.DIST_L2, 5)
    _, sure_fg = cv2.threshold(dist_transform, 0.5 * dist_transform.max(), 255, 0)
    sure_fg = np.uint8(sure_fg)
    unknown = cv2.subtract(sure_bg, sure_fg)
    _, markers = cv2.connectedComponents(sure_fg)
    markers = markers + 1
    markers[unknown == 255] = 0
    markers = cv2.watershed(img, markers)
    img[markers == -1] = [0, 0, 255]
    return img

def grabcut_remove_background(frame):
    h, w = frame.shape[:2]
    rect = (int(w*0.05), int(h*0.05), int(w*0.9), int(h*0.9))
    mask = np.zeros(frame.shape[:2], np.uint8)
    bgdModel = np.zeros((1,65), np.float64)
    fgdModel = np.zeros((1,65), np.float64)
    cv2.grabCut(frame, mask, rect, bgdModel, fgdModel, 5, cv2.GC_INIT_WITH_RECT)
    mask2 = np.where((mask==2)|(mask==0), 0, 1).astype('uint8')
    result = frame * mask2[:,:,np.newaxis]
    b, g, r = cv2.split(result)
    alpha = (mask2 * 255).astype(np.uint8)
    return cv2.merge([b, g, r, alpha])

def color_key_remove_background(frame, lower_h=35, upper_h=85):
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    lower = np.array([lower_h, 50, 50])
    upper = np.array([upper_h, 255, 255])
    mask = cv2.inRange(hsv, lower, upper)
    mask_inv = cv2.bitwise_not(mask)
    res = cv2.bitwise_and(frame, frame, mask=mask_inv)
    b, g, r = cv2.split(res)
    alpha = mask_inv
    return cv2.merge([b, g, r, alpha])


# ==============================================================================
# 2. الواجهة الرئيسية الاحترافية (Pro UI Smart Enhancer)
# ==============================================================================

DARK_STYLE = """
QMainWindow {
    background-color: #0f172a;
}
QWidget {
    color: #f8fafc;
    font-family: 'Segoe UI', Arial, sans-serif;
    font-size: 13px;
}
QGroupBox {
    border: 1px solid #334155;
    border-radius: 8px;
    margin-top: 12px;
    padding-top: 10px;
    background-color: #1e293b;
    font-weight: bold;
    color: #38bdf8;
}
QGroupBox::title {
    subcontrol-origin: margin;
    left: 12px;
    padding: 0 5px;
}
QPushButton {
    background-color: #334155;
    color: #f8fafc;
    border: 1px solid #475569;
    border-radius: 6px;
    padding: 8px 14px;
    font-weight: 600;
}
QPushButton:hover {
    background-color: #3b82f6;
    border-color: #60a5fa;
}
QPushButton:pressed {
    background-color: #1d4ed8;
}
QLineEdit, QComboBox, QSpinBox {
    background-color: #0f172a;
    border: 1px solid #334155;
    border-radius: 6px;
    padding: 6px;
    color: #38bdf8;
}
QComboBox::drop-down {
    border: none;
}
QTabBar::tab {
    background: #1e293b;
    color: #94a3b8;
    padding: 8px 16px;
    border-top-left-radius: 6px;
    border-top-right-radius: 6px;
    margin-right: 2px;
    font-weight: bold;
}
QTabBar::tab:selected {
    background: #3b82f6;
    color: #ffffff;
}
QSlider::groove:horizontal {
    height: 6px;
    background: #334155;
    border-radius: 3px;
}
QSlider::handle:horizontal {
    background: #38bdf8;
    width: 16px;
    margin: -5px 0;
    border-radius: 8px;
}
QStatusBar {
    background-color: #1e293b;
    color: #94a3b8;
    border-top: 1px solid #334155;
}
"""

class SmartEnhancerPro(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("VisionStudio Pro - محرر معالجة الصور والفيديو الاحترافي")
        self.setGeometry(30, 30, 1380, 850)
        self.setStyleSheet(DARK_STYLE)

        # Variables State
        self.zoom_scale = 1.0
        self.orig_image = None
        self.proc_frame = None
        self.video_path = None
        self.cap = None
        self.timer = QtCore.QTimer(self)
        self.fps = 30
        self.playing = False
        self.recording = False
        self.writer = None
        self.record_out_path = None

        self.crop_rect = None
        self.resize_scale = 1.0
        self.rotate_angle = 0
        self.camera_index = 0

        self.init_ui()

    def init_ui(self):
        central = QtWidgets.QWidget()
        self.setCentralWidget(central)
        main_layout = QtWidgets.QHBoxLayout(central)
        main_layout.setSpacing(12)

        # -------------------------------------------------------------
        # Left Panel: Controls & Toolbars (Sidebar)
        # -------------------------------------------------------------
        sidebar = QtWidgets.QVBoxLayout()
        sidebar_widget = QtWidgets.QWidget()
        sidebar_widget.setLayout(sidebar)
        sidebar_widget.setFixedWidth(420)

        # 1. Main Actions Box
        gb_io = QtWidgets.QGroupBox("المصدر والوسائط (Media Source)")
        io_layout = QtWidgets.QVBoxLayout()

        grid_io = QtWidgets.QGridLayout()
        self.btn_load_image = QtWidgets.QPushButton("🖼️ فتح صورة")
        self.btn_load_video = QtWidgets.QPushButton("🎥 فتح فيديو")
        self.btn_open_cam = QtWidgets.QPushButton("📹 الكاميرا")
        self.btn_save_img = QtWidgets.QPushButton("💾 حفظ الصورة")

        grid_io.addWidget(self.btn_load_image, 0, 0)
        grid_io.addWidget(self.btn_load_video, 0, 1)
        grid_io.addWidget(self.btn_open_cam, 1, 0)
        grid_io.addWidget(self.btn_save_img, 1, 1)
        io_layout.addLayout(grid_io)

        # Custom Path Load
        path_layout = QtWidgets.QHBoxLayout()
        self.txt_path_input = QtWidgets.QLineEdit()
        self.txt_path_input.setPlaceholderText("أدخل مسار صورة أو فيديو هنا...")
        self.btn_load_path = QtWidgets.QPushButton("تحميل")
        path_layout.addWidget(self.txt_path_input)
        path_layout.addWidget(self.btn_load_path)
        io_layout.addLayout(path_layout)

        gb_io.setLayout(io_layout)
        sidebar.addWidget(gb_io)

        # 2. Operations & Enhancements Tabs
        self.tabs = QtWidgets.QTabWidget()

        # Tab 1: Operations
        self.tab_ops = QtWidgets.QWidget()
        ops_layout = QtWidgets.QVBoxLayout(self.tab_ops)
        self.combo_ops = QtWidgets.QComboBox()
        self.combo_ops.addItems([
            "اختر العملية (None)", "property of photo", "Histogram Equalization",
            "Gaussian Denoise", "Median Denoise", "Bilateral Denoise", "Non-local Means Denoise",
            "Sharpen", "Smoothing", "Edge Sobel", "Edge Canny", "Line Detection",
            "Threshold Binary", "Morph Erode", "Morph Dilate", "Morph Open", "Morph Close",
            "Segmentation KMeans", "Watershed Segmentation"
        ])
        ops_layout.addWidget(self.combo_ops)
        self.tabs.addTab(self.tab_ops, "العمليات الفنية")

        # Tab 2: Enhancements
        self.tab_enh = QtWidgets.QWidget()
        enh_layout = QtWidgets.QFormLayout(self.tab_enh)
        self.combo_enh = QtWidgets.QComboBox()
        self.combo_enh.addItems(["اختر تحسين", "Brightness/Contrast", "Gamma Correction", "CLAHE Equalization"])
        enh_layout.addRow("النوع:", self.combo_enh)

        self.slider_brightness = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.slider_brightness.setRange(-100, 100)
        self.slider_brightness.setValue(0)
        enh_layout.addRow("Brightness", self.slider_brightness)

        self.slider_contrast = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.slider_contrast.setRange(-100, 100)
        self.slider_contrast.setValue(0)
        enh_layout.addRow("Contrast", self.slider_contrast)

        self.slider_gamma = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.slider_gamma.setRange(10, 300)
        self.slider_gamma.setValue(100)
        enh_layout.addRow("Gamma (×0.01)", self.slider_gamma)
        self.tabs.addTab(self.tab_enh, "تحسين الألوان")

        sidebar.addWidget(self.tabs)

        # 3. Transform Group
        gb_trans = QtWidgets.QGroupBox("التحويلات الهندسيّة (Transformations)")
        trans_layout = QtWidgets.QVBoxLayout()

        btn_crop = QtWidgets.QPushButton("✂️ قص (Crop Custom)")
        btn_crop.clicked.connect(self.crop_dialog)
        trans_layout.addWidget(btn_crop)

        resize_box = QtWidgets.QHBoxLayout()
        resize_box.addWidget(QtWidgets.QLabel("الحجم %:"))
        self.spin_scale = QtWidgets.QSpinBox()
        self.spin_scale.setRange(10, 400)
        self.spin_scale.setValue(100)
        btn_apply_resize = QtWidgets.QPushButton("تطبيق الحجم")
        btn_apply_resize.clicked.connect(self.apply_resize_setting)
        resize_box.addWidget(self.spin_scale)
        resize_box.addWidget(btn_apply_resize)
        trans_layout.addLayout(resize_box)

        rotate_box = QtWidgets.QHBoxLayout()
        btn_rot_left = QtWidgets.QPushButton("↺ 90°")
        btn_rot_right = QtWidgets.QPushButton("↻ 90°")
        btn_rot_left.clicked.connect(lambda: self.rotate_by(-90))
        btn_rot_right.clicked.connect(lambda: self.rotate_by(90))
        rotate_box.addWidget(btn_rot_left)
        rotate_box.addWidget(btn_rot_right)
        trans_layout.addLayout(rotate_box)

        gb_trans.setLayout(trans_layout)
        sidebar.addWidget(gb_trans)

        # 4. Background & Arithmetic Group
        gb_adv = QtWidgets.QGroupBox("حذف الخلفية والعمليات المنطقية")
        adv_layout = QtWidgets.QFormLayout()
        self.combo_bg = QtWidgets.QComboBox()
        self.combo_bg.addItems(["None", "ColorKey (Green)", "GrabCut"])
        self.combo_bg.currentIndexChanged.connect(self.on_parameters_changed)
        adv_layout.addRow("حذف الخلفية:", self.combo_bg)

        self.combo_arith = QtWidgets.QComboBox()
        self.combo_arith.addItems(["None", "Add (scalar)", "Sub (scalar)", "Mul (scalar)", "Div (scalar)", "Bitwise AND", "Bitwise OR", "Bitwise XOR"])
        self.combo_arith.currentIndexChanged.connect(self.on_parameters_changed)
        self.spin_scalar = QtWidgets.QSpinBox()
        self.spin_scalar.setRange(-255, 255)
        self.spin_scalar.setValue(20)
        self.spin_scalar.valueChanged.connect(self.on_parameters_changed)
        adv_layout.addRow("عملية رياضية:", self.combo_arith)
        adv_layout.addRow("القيمة المقترنة:", self.spin_scalar)
        gb_adv.setLayout(adv_layout)
        sidebar.addWidget(gb_adv)

        # Video Control Panel
        gb_video = QtWidgets.QGroupBox("تحكم التسجيل والفيديو")
        v_layout = QtWidgets.QHBoxLayout()
        self.btn_play = QtWidgets.QPushButton("▶ تشغيل/إيقاف")
        self.btn_record = QtWidgets.QPushButton("🔴 بدء التسجيل")
        self.btn_export = QtWidgets.QPushButton("⚡ تصدير كامل")
        v_layout.addWidget(self.btn_play)
        v_layout.addWidget(self.btn_record)
        v_layout.addWidget(self.btn_export)
        gb_video.setLayout(v_layout)
        sidebar.addWidget(gb_video)

        sidebar.addStretch()

        # -------------------------------------------------------------
        # Right Panel: Workspace Display (Main Canvas Area)
        # -------------------------------------------------------------
        workspace = QtWidgets.QVBoxLayout()

        # Header Zoom Controls
        zoom_bar = QtWidgets.QHBoxLayout()
        lbl_title = QtWidgets.QLabel("معاينة العرض الحي (Interactive Dual Viewer)")
        lbl_title.setStyleSheet("font-size: 16px; font-weight: bold; color: #38bdf8;")
        self.btn_zoom_in = QtWidgets.QPushButton("🔍 تكبير المعاينة")
        self.btn_zoom_out = QtWidgets.QPushButton("🔎 تصغير المعاينة")
        zoom_bar.addWidget(lbl_title)
        zoom_bar.addStretch()
        zoom_bar.addWidget(self.btn_zoom_in)
        zoom_bar.addWidget(self.btn_zoom_out)
        workspace.addLayout(zoom_bar)

        # Displays
        display_layout = QtWidgets.QHBoxLayout()

        # Frame Before
        frame_before_box = QtWidgets.QVBoxLayout()
        lbl_b_title = QtWidgets.QLabel("الصورة الأصلية (BEFORE)")
        lbl_b_title.setAlignment(QtCore.Qt.AlignCenter)
        lbl_b_title.setStyleSheet("color: #94a3b8; font-weight: bold;")
        self.label_before = QtWidgets.QLabel("قم بفتح صورة أو فيديو للعرض")
        self.label_before.setAlignment(QtCore.Qt.AlignCenter)
        self.label_before.setMinimumSize(420, 480)
        self.label_before.setStyleSheet("background-color: #020617; border: 2px dashed #334155; border-radius: 10px;")
        frame_before_box.addWidget(lbl_b_title)
        frame_before_box.addWidget(self.label_before)

        # Frame After
        frame_after_box = QtWidgets.QVBoxLayout()
        lbl_a_title = QtWidgets.QLabel("الصورة المعالجة (AFTER)")
        lbl_a_title.setAlignment(QtCore.Qt.AlignCenter)
        lbl_a_title.setStyleSheet("color: #38bdf8; font-weight: bold;")
        self.label_after = QtWidgets.QLabel("النتائج المعالجة تظهر هنا")
        self.label_after.setAlignment(QtCore.Qt.AlignCenter)
        self.label_after.setMinimumSize(420, 480)
        self.label_after.setStyleSheet("background-color: #020617; border: 2px solid #3b82f6; border-radius: 10px;")
        frame_after_box.addWidget(lbl_a_title)
        frame_after_box.addWidget(self.label_after)

        display_layout.addLayout(frame_before_box)
        display_layout.addLayout(frame_after_box)
        workspace.addLayout(display_layout)

        # Build Main View
        main_layout.addWidget(sidebar_widget)
        main_layout.addLayout(workspace)

        # Connect Events
        self.btn_load_image.clicked.connect(self.load_image)
        self.btn_load_video.clicked.connect(self.load_video)
        self.btn_open_cam.clicked.connect(self.open_camera)
        self.btn_load_path.clicked.connect(self.load_from_custom_path)
        self.btn_save_img.clicked.connect(self.save_image)

        self.btn_play.clicked.connect(self.toggle_play)
        self.btn_record.clicked.connect(self.toggle_record)
        self.btn_export.clicked.connect(self.export_full_video)

        self.btn_zoom_in.clicked.connect(self.zoom_in)
        self.btn_zoom_out.clicked.connect(self.zoom_out)

        self.timer.timeout.connect(self.next_frame)

        self.combo_ops.currentIndexChanged.connect(self.on_parameters_changed)
        self.combo_enh.currentIndexChanged.connect(self.on_parameters_changed)
        self.slider_brightness.valueChanged.connect(self.on_parameters_changed)
        self.slider_contrast.valueChanged.connect(self.on_parameters_changed)
        self.slider_gamma.valueChanged.connect(self.on_parameters_changed)

        self.statusBar().showMessage("النظام جاهز للعمل - Ready")

    # -------------------------------------------------------------
    # Logic & Event Handlers
    # -------------------------------------------------------------
    def load_from_custom_path(self):
        path = self.txt_path_input.text().strip()
        if not path or not os.path.exists(path):
            QtWidgets.QMessageBox.warning(self, "خطأ بالمسار", "المسار المكتوب غير موجود تحقق منه مجدداً.")
            return

        ext = path.split('.')[-1].lower()
        if ext in ['png', 'jpg', 'jpeg', 'bmp', 'webp']:
            self.stop_video_if_any()
            img = cv2.imread(path)
            if img is not None:
                self.video_path = None
                self.orig_image = img
                transformed = self.apply_transformations(self.orig_image)
                proc = self.apply_pipeline(transformed)
                self.proc_frame = proc
                self.display_before_after(transformed, proc)
                self.statusBar().showMessage(f"تم تحميل الصورة من المسار: {path}")
        elif ext in ['mp4', 'avi', 'mov', 'mkv']:
            self.stop_video_if_any()
            cap = cv2.VideoCapture(path)
            if cap.isOpened():
                self.video_path = path
                self.cap = cap
                fps = int(cap.get(cv2.CAP_PROP_FPS))
                self.fps = fps if fps > 0 else 25
                self.timer.setInterval(int(1000 / self.fps))
                self.playing = True
                self.timer.start()
                self.statusBar().showMessage(f"تم تشغيل الفيديو من المسار: {path}")

    def crop_dialog(self):
        if self.orig_image is None and self.cap is None:
            QtWidgets.QMessageBox.information(self, "تنبيه", "حمل صورة أو افتح فيديو لتطبيق القص.")
            return
        text, ok = QtWidgets.QInputDialog.getText(self, "القص", "أدخل الإحداثيات x,y,w,h (مثال: 100,50,400,300):")
        if ok and text:
            try:
                parts = [int(p.strip()) for p in text.split(',')]
                if len(parts) == 4:
                    self.crop_rect = tuple(parts)
                    self.on_parameters_changed()
            except:
                QtWidgets.QMessageBox.warning(self, "خطأ", "فشل قراءة القيم المفصولة بفواصل.")

    def apply_resize_setting(self):
        self.resize_scale = self.spin_scale.value() / 100.0
        self.on_parameters_changed()

    def rotate_by(self, deg):
        self.rotate_angle = (self.rotate_angle + deg) % 360
        self.on_parameters_changed()

    def zoom_in(self):
        self.zoom_scale *= 1.2
        self.on_parameters_changed()

    def zoom_out(self):
        self.zoom_scale /= 1.2
        self.on_parameters_changed()

    def apply_transformations(self, frame):
        out = frame.copy()
        if self.crop_rect is not None:
            x, y, w, h = self.crop_rect
            H, W = out.shape[:2]
            x, y = max(0, min(x, W-1)), max(0, min(y, H-1))
            w, h = max(1, min(w, W-x)), max(1, min(h, H-y))
            out = out[y:y+h, x:x+w]

        if self.resize_scale != 1.0:
            nw = int(out.shape[1] * self.resize_scale)
            nh = int(out.shape[0] * self.resize_scale)
            if nw > 0 and nh > 0:
                out = cv2.resize(out, (nw, nh), interpolation=cv2.INTER_AREA)

        if self.rotate_angle != 0:
            (h, w) = out.shape[:2]
            center = (w // 2, h // 2)
            M = cv2.getRotationMatrix2D(center, -self.rotate_angle, 1.0)
            cos, sin = np.abs(M[0, 0]), np.abs(M[0, 1])
            nW, nH = int((h * sin) + (w * cos)), int((h * cos) + (w * sin))
            M[0, 2] += (nW / 2) - center[0]
            M[1, 2] += (nH / 2) - center[1]
            out = cv2.warpAffine(out, M, (nW, nH))
        return out

    def apply_pipeline(self, frame):
        out = frame.copy()
        op = self.combo_ops.currentText()
        if op == "property of photo": self.show_image_info(out)
        elif op == "Histogram Equalization": out = histogram_equalization(out)
        elif op == "Gaussian Denoise": out = denoise_gaussian(out)
        elif op == "Median Denoise": out = denoise_median(out)
        elif op == "Bilateral Denoise": out = denoise_bilateral(out)
        elif op == "Non-local Means Denoise": out = denoise_nlmeans(out)
        elif op == "Smoothing": out = smoothing(out)
        elif op == "Sharpen": out = sharpen(out)
        elif op == "Edge Sobel": out = edge_sobel(out)
        elif op == "Edge Canny": out = edge_canny(out)
        elif op == "Line Detection": out = line_detection(out)
        elif op == "Threshold Binary": out = threshold_binary(out)
        elif op == "Morph Erode": out = morph_erode(out)
        elif op == "Morph Dilate": out = morph_dilate(out)
        elif op == "Morph Open": out = morph_open(out)
        elif op == "Morph Close": out = morph_close(out)
        elif op == "Segmentation KMeans": out = segmentation_kmeans(out)
        elif op == "Watershed Segmentation": out = watershed_segmentation(out)

        enh = self.combo_enh.currentText()
        if enh == "Brightness/Contrast":
            out = adjust_brightness_contrast(out, self.slider_brightness.value(), self.slider_contrast.value())
        elif enh == "Gamma Correction":
            out = gamma_correction(out, self.slider_gamma.value() / 100.0)
        elif enh == "CLAHE Equalization":
            out = clahe_equalization(out)

        bg_mode = self.combo_bg.currentText()
        if bg_mode in ["ColorKey (Green)", "GrabCut"]:
            rgba = color_key_remove_background(out) if bg_mode == "ColorKey (Green)" else grabcut_remove_background(out)
            if rgba.shape[2] == 4:
                b, g, r, a = cv2.split(rgba)
                alpha_norm = (a.astype(np.float32) / 255.0)[:, :, np.newaxis]
                bg = np.ones_like(rgba[:, :, :3], dtype=np.uint8) * 255
                out = (rgba[:, :, :3].astype(np.float32) * alpha_norm + bg.astype(np.float32) * (1 - alpha_norm)).astype(np.uint8)

        arith = self.combo_arith.currentText()
        scalar = int(self.spin_scalar.value())
        if arith == "Add (scalar)": out = cv2.add(out, np.array([scalar]*3, dtype=np.uint8))
        elif arith == "Sub (scalar)": out = cv2.subtract(out, np.array([scalar]*3, dtype=np.uint8))
        elif arith == "Mul (scalar)": out = cv2.convertScaleAbs(out.astype(np.float32) * (1 + scalar/100.0))
        elif arith == "Div (scalar)": out = cv2.convertScaleAbs(out.astype(np.float32) / float(scalar if scalar!=0 else 1))
        elif arith in ["Bitwise AND", "Bitwise OR", "Bitwise XOR"]:
            operand = self.apply_transformations(self.orig_image) if self.orig_image is not None else out.copy()
            if operand.shape[:2] != out.shape[:2]:
                operand = cv2.resize(operand, (out.shape[1], out.shape[0]))
            if arith == "Bitwise AND": out = cv2.bitwise_and(out, operand)
            elif arith == "Bitwise OR": out = cv2.bitwise_or(out, operand)
            elif arith == "Bitwise XOR": out = cv2.bitwise_xor(out, operand)
        return out

    def load_image(self):
        self.stop_video_if_any()
        path, _ = QtWidgets.QFileDialog.getOpenFileName(self, "اختر صورة", "", "Images (*.png *.jpg *.jpeg *.bmp *.webp)")
        if path:
            self.txt_path_input.setText(path)
            self.load_from_custom_path()

    def load_video(self):
        self.stop_video_if_any()
        path, _ = QtWidgets.QFileDialog.getOpenFileName(self, "اختر فيديو", "", "Videos (*.mp4 *.avi *.mov *.mkv)")
        if path:
            self.txt_path_input.setText(path)
            self.load_from_custom_path()

    def open_camera(self):
        self.stop_video_if_any()
        cap = cv2.VideoCapture(self.camera_index)
        if not cap.isOpened():
            QtWidgets.QMessageBox.warning(self, "خطأ", "تعذر فتح الكاميرا الموصلة بالجهاز.")
            return
        self.cap = cap
        self.video_path = None
        self.playing = True
        self.timer.setInterval(33)
        self.timer.start()
        self.statusBar().showMessage("تم فتح الكاميرا المباشرة")

    def toggle_play(self):
        if self.cap is None and self.orig_image is not None:
            transformed = self.apply_transformations(self.orig_image)
            processed = self.apply_pipeline(transformed)
            self.display_before_after(transformed, processed)
            return
        if self.playing:
            self.playing = False
            self.timer.stop()
            self.statusBar().showMessage("إيقاف مؤقت")
        else:
            self.playing = True
            self.timer.start()
            self.statusBar().showMessage("جارٍ التشغيل...")

    def stop_video_if_any(self):
        if self.cap:
            try: self.cap.release()
            except: pass
            self.cap = None
        if self.recording:
            self._stop_recording(finalize=True)

    def next_frame(self):
        if self.cap is None: return
        ret, frame = self.cap.read()
        if not ret:
            self.timer.stop()
            self.playing = False
            self.statusBar().showMessage("نهاية المقطع أو انفصال الكاميرا")
            return
        transformed = self.apply_transformations(frame)
        processed = self.apply_pipeline(transformed)
        self.proc_frame = processed
        self.display_before_after(transformed, processed)
        if self.recording and self.writer:
            try: self.writer.write(cv2.hconcat([transformed, processed]))
            except Exception as e: print("Rec Error:", e)

    def display_before_after(self, before, after):
        try:
            pix_before = self.cv2qt(before)
            pix_after = self.cv2qt(after)
            if self.zoom_scale != 1.0:
                w = int(pix_after.width() * self.zoom_scale)
                h = int(pix_after.height() * self.zoom_scale)
                pix_after = pix_after.scaled(w, h, QtCore.Qt.KeepAspectRatio)
            self.label_before.setPixmap(pix_before)
            self.label_after.setPixmap(pix_after)
        except Exception as e: print("Display exception:", e)

    def cv2qt(self, frame):
        if frame is None: return QtGui.QPixmap()
        if len(frame.shape) == 2:
            rgb = cv2.cvtColor(frame, cv2.COLOR_GRAY2RGB)
        elif frame.shape[2] == 4:
            rgb = cv2.cvtColor(cv2.cvtColor(frame, cv2.COLOR_BGRA2BGR), cv2.COLOR_BGR2RGB)
        else:
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        h, w, ch = rgb.shape
        qimg = QtGui.QImage(rgb.data, w, h, ch * w, QtGui.QImage.Format_RGB888)
        pix = QtGui.QPixmap.fromImage(qimg)
        return pix.scaled(self.label_before.width(), self.label_before.height(), QtCore.Qt.KeepAspectRatio)

    def on_parameters_changed(self):
        if self.orig_image is not None and self.cap is None:
            transformed = self.apply_transformations(self.orig_image)
            processed = self.apply_pipeline(transformed)
            self.proc_frame = processed
            self.display_before_after(transformed, processed)

    def save_image(self):
        if self.proc_frame is None:
            QtWidgets.QMessageBox.information(self, "تنبيه", "لا توجد صورة معالجة جاهزة للحفظ.")
            return
        path, _ = QtWidgets.QFileDialog.getSaveFileName(self, "حفظ الصورة المعالجة", "", "PNG Files (*.png);;JPG Files (*.jpg)")
        if path:
            cv2.imwrite(path, self.proc_frame)
            QtWidgets.QMessageBox.information(self, "تم الحفظ", f"تمت عملية حفظ الصورة بإنشاء الملف:\n{path}")

    def toggle_record(self):
        if self.cap is None or self.proc_frame is None:
            QtWidgets.QMessageBox.information(self, "تنبيه", "افتح فيديو أو بث مباشر أولاً للتسجيل.")
            return
        if not self.recording:
            path, _ = QtWidgets.QFileDialog.getSaveFileName(self, "مسار تسجيل الفيديو", "", "AVI (*.avi);;MP4 (*.mp4)")
            if not path: return
            ext = path.split('.')[-1].lower()
            fourcc = cv2.VideoWriter_fourcc(*('mp4v' if ext in ['mp4','m4v'] else 'XVID'))
            h, w = self.proc_frame.shape[:2]
            try:
                self.writer = cv2.VideoWriter(path, fourcc, self.fps, (w * 2, h))
                self.recording = True
                self.record_out_path = path
                self.btn_record.setText("⏹ إيقاف التسجيل")
                self.btn_record.setStyleSheet("background-color: #ef4444; color: white;")
                self.statusBar().showMessage(f"التسجيل نشط الان 🔴 → {path}")
            except Exception as e:
                QtWidgets.QMessageBox.warning(self, "خطأ التسجيل", str(e))
        else:
            self._stop_recording(finalize=True)

    def _stop_recording(self, finalize=False):
        if self.writer:
            self.writer.release()
            self.writer = None
        self.recording = False
        self.btn_record.setText("🔴 بدء التسجيل")
        self.btn_record.setStyleSheet("")
        if finalize and self.record_out_path:
            QtWidgets.QMessageBox.information(self, "تم التسجيل", f"تم حفظ المقطع المزدوج بنجاح:\n{self.record_out_path}")
            self.record_out_path = None

    def export_full_video(self):
        if self.video_path is None:
            QtWidgets.QMessageBox.information(self, "تنبيه", "حمل ملف فيديو أولاً لتصديره بالكامل.")
            return
        out_path, _ = QtWidgets.QFileDialog.getSaveFileName(self, "تصدير الفيديو المعالج بالكامل", "", "MP4 (*.mp4);;AVI (*.avi)")
        if not out_path: return

        cap2 = cv2.VideoCapture(self.video_path)
        total_frames = int(cap2.get(cv2.CAP_PROP_FRAME_COUNT)) or 0
        w, h = int(cap2.get(cv2.CAP_PROP_FRAME_WIDTH)), int(cap2.get(cv2.CAP_PROP_FRAME_HEIGHT))
        fps = int(cap2.get(cv2.CAP_PROP_FPS)) or self.fps
        ext = out_path.split('.')[-1].lower()

        writer2 = cv2.VideoWriter(out_path, cv2.VideoWriter_fourcc(*('mp4v' if ext in ['mp4','m4v'] else 'XVID')), fps, (w*2, h))
        progress = QtWidgets.QProgressDialog("جارٍ تصدير ومعالجة الفيديو بالكامل...", "إلغاء", 0, total_frames, self)
        progress.setWindowModality(QtCore.Qt.WindowModal)

        cnt = 0
        while True:
            ret, frame = cap2.read()
            if not ret: break
            transformed = self.apply_transformations(frame)
            processed = self.apply_pipeline(transformed)
            if transformed.shape[:2] != (h, w): transformed = cv2.resize(transformed, (w, h))
            if processed.shape[:2] != (h, w): processed = cv2.resize(processed, (w, h))
            writer2.write(cv2.hconcat([transformed, processed]))
            cnt += 1
            progress.setValue(cnt)
            if progress.wasCanceled(): break

        writer2.release()
        cap2.release()
        progress.close()
        if not progress.wasCanceled():
            QtWidgets.QMessageBox.information(self, "تم التصدير", f"تم تصدير الفيديو المعالج كاملاً بنجاح:\n{out_path}")

    def show_image_info(self, frame):
        if frame is None: return
        h, w = frame.shape[:2]
        ch = frame.shape[2] if len(frame.shape) == 3 else 1
        QtWidgets.QMessageBox.information(self, "خواص الصورة الحالية", f"العرض (Width): {w} px\nالارتفاع (Height): {h} px\nعدد القنوات (Channels): {ch}\nنوع البيانات (Dtype): {frame.dtype}")


# ==============================================================================
# 3. شاشة الترحيب الاحترافية مودرن (Pro Welcome Dialog)
# ==============================================================================

class ProWelcomeScreen(QtWidgets.QDialog):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("مرحباً بك - VisionStudio Pro")
        self.setFixedSize(550, 420)
        self.setStyleSheet("""
            QDialog {
                background-color: #0f172a;
                border: 1px solid #3b82f6;
                border-radius: 12px;
            }
            QLabel { color: #f8fafc; font-family: 'Segoe UI'; }
            QPushButton {
                background-color: #3b82f6;
                color: white;
                font-weight: bold;
                font-size: 15px;
                border-radius: 8px;
                padding: 10px;
            }
            QPushButton:hover { background-color: #2563eb; }
        """)

        layout = QtWidgets.QVBoxLayout()
        layout.setContentsMargins(35, 35, 35, 35)

        title = QtWidgets.QLabel("VISION STUDIO PRO")
        title.setAlignment(QtCore.Qt.AlignCenter)
        title.setStyleSheet("font-size: 26px; font-weight: 900; color: #38bdf8; letter-spacing: 2px;")
        layout.addWidget(title)

        subtitle = QtWidgets.QLabel("منصة معالجة الصور والرؤية الحاسوبية الشاملة")
        subtitle.setAlignment(QtCore.Qt.AlignCenter)
        subtitle.setStyleSheet("font-size: 13px; color: #94a3b8; margin-bottom: 20px;")
        layout.addWidget(subtitle)

        team_box = QtWidgets.QGroupBox("فريق العمل والمشروع")
        team_layout = QtWidgets.QVBoxLayout()
        team_info = QtWidgets.QLabel("• محمد العلواني\n• عبدالله فارع\n• ابان الشرعبي")
        team_info.setStyleSheet("font-size: 14px; color: #cbd5e1; line-height: 150%;")
        team_layout.addWidget(team_info)

        supervisor = QtWidgets.QLabel("تحت إشراف الأستاذ: مالك المصنف")
        supervisor.setStyleSheet("font-size: 13px; font-weight: bold; color: #38bdf8; margin-top: 5px;")
        team_layout.addWidget(supervisor)

        team_box.setLayout(team_layout)
        layout.addWidget(team_box)

        layout.addStretch()

        btn_start = QtWidgets.QPushButton("🚀 بدء تشغيل المحرر الاحترافي")
        btn_start.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        btn_start.clicked.connect(self.accept)
        layout.addWidget(btn_start)

        self.setLayout(layout)


# ==============================================================================
# 4. نقطة الانطلاق الرئيسية (Application Entry Point)
# ==============================================================================

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    welcome = ProWelcomeScreen()
    if welcome.exec_() == QtWidgets.QDialog.Accepted:
        main_win = SmartEnhancerPro()
        main_win.show()
        sys.exit(app.exec_())
